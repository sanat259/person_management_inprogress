package controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.People;

/**
 * Servlet implementation class DeletePeople
 */
public class DeletePeople extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, NullPointerException {
		System.out.println("Delete Servlet triggered");
		/**
		 * @param Get the request parameters
		 */
		
		// Get the original search parameter to update the list later. Http session updates the query result to display page.
		People search_query = (People) request.getSession(false).getAttribute("search_query");
		HttpSession session = request.getSession();
		
		//Get 
		String username = request.getParameter("delete_username").toString();
		System.out.println("Into Delete Controller" + "Params " + username);

		// Dao--> our data acess object. Will Delete given row
		PeopleDao dao = new PeopleDao();
		
			boolean isPresent = dao.fetchRecord(username);
			System.out.println("Fetching Query before deleting:" +isPresent);

			if(!isPresent) {
				System.out.println("Unable to Delete. Record is not available in the database.");
			}
			else {
				boolean result = dao.deletePeople(username);
				System.out.println(" Delete Controller - Deleted user: " + result);
			}
			
			//Set the result of delete in session.
			session.setAttribute("deleteResult", isPresent);
			
		/** To display users after delete **/
			try {
				String username1 = (search_query.getUsername()== null||search_query.getUsername()=="")? "": search_query.getUsername() ;
				String email2 = search_query.getEmail()== null? "": search_query.getEmail() ;
				String first_name1 = search_query.getFirst_name()== null? "": search_query.getFirst_name() ;
				String last_name1 = search_query.getLast_name()== null? "": search_query.getLast_name() ;
				ArrayList<People> people = dao.getPeople(username1, email2, first_name1, last_name1);
				request.setAttribute("people", people);
				RequestDispatcher rd = request.getRequestDispatcher("showPeople.jsp");
				
				rd.forward(request, response);
				return;
				}
				catch (Exception e) {
					ArrayList<People> people = dao.getPeople("", "", "", "");
					request.setAttribute("people", people);
					RequestDispatcher rd = request.getRequestDispatcher("showPeople.jsp");
					rd.forward(request, response);				
				}
	}

}
