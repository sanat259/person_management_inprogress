package controllers;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.People;

/**
 * Servlet implementation class UpdatePeople
 */
public class UpdatePeople extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, NullPointerException {
		/**
		 * Get the request @param
		 * 
		 */
		
		// Get the original search parameter to update the list later.
		People search_query = (People) request.getSession(false).getAttribute("search_query");
		HttpSession session = request.getSession();

		
		
		try {
		People search_user = new People();
		search_user.setUsername(request.getParameter("user").toString().trim());
		search_user.setFirst_name(request.getParameter("first_name").toString().trim());
		search_user.setLast_name(request.getParameter("last_name").toString().trim());
		search_user.setEmail(request.getParameter("email").toString().trim());
		System.out.println("The update: Search query:"+ search_user);
		}
		catch (Exception e) {
			// TODO: handle exception
			
		}
		//Set up parameters to persorm update.
		String username = request.getParameter("update_username").toString();
		String email = request.getParameter("update_email").toString();
		String first_name = request.getParameter("update_first_name").toString();
		String last_name = request.getParameter("update_last_name").toString();
		String role = request.getParameter("update_role").toString();
		// String password = request.getParameter("password").toString();
		System.out.println(
				"Into Update Controller" + "Params " + username + " " + email + " " + first_name + " " + last_name);

		// Dao--> our data access object. Will create new person
		PeopleDao dao = new PeopleDao();
		boolean result = dao.updatePeople(username, email, first_name, last_name, role);
		System.out.println("  Controller - Update user: " + result);
		if (result) {
			session.setAttribute("updateResult", result);
		}
		

		/** To display users after update **/
		try {
			String username1 = (search_query.getUsername()== null||search_query.getUsername()=="")? "": search_query.getUsername() ;
			String email2 = search_query.getEmail()== null? "": search_query.getEmail() ;
			String first_name1 = search_query.getFirst_name()== null? "": search_query.getFirst_name() ;
			String last_name1 = search_query.getLast_name()== null? "": search_query.getLast_name() ;
			ArrayList<People> people = dao.getPeople(username1, email2, first_name1, last_name1);
			request.setAttribute("people", people);
			RequestDispatcher rd = request.getRequestDispatcher("showPeople.jsp");
			rd.forward(request, response);
			return;
			}
			catch (Exception e) {
				ArrayList<People> people = dao.getPeople("", "", "", "");
				request.setAttribute("people", people);
				RequestDispatcher rd = request.getRequestDispatcher("showPeople.jsp");
				rd.forward(request, response);				
			}

	}

}
