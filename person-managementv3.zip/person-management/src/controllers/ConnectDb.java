/**
 * 
 */
package controllers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * @author sanat.parmar
 * The class to establish and remove connection with the database.
 */
public class ConnectDb {
	private Connection connection = null;

	/**
	 * 
	 * @param link
	 * @param username
	 * @param pass
	 * @return connection object. Null in case if connection is not established.
	 */
	public Connection getConnection(String link, String username, String pass) {
	
			try {
				//Load the driver and konnect.
				Class.forName("com.mysql.jdbc.Driver");
				connection = DriverManager.getConnection(link, username, pass );
				System.out.println("ConnectionDB: Connection established");
				return connection;

			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Cannot establish connection.");
		
		return connection;
	}

	
	//Close the connection
	public void closeConnection() {
		if(connection!= null) {
			try {
				connection.close();
				System.out.println("ConnectionDB: Connection closed");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}


}
