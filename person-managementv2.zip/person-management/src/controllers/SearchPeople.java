package controllers;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.PreparedStatement;

import model.People;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Servlet implementation class SearchPeople
 */
public class SearchPeople extends HttpServlet {
	ArrayList<People> people;
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SearchPeople() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, IllegalArgumentException {
		// TODO Auto-generated method stub
		/*
		 * String name = null; String session_email = null;
		 * 
		 * response.getWriter().append("Served at: ").append(request.getContextPath());
		 * // Get the old session and invalidate HttpSession oldSession =
		 * request.getSession(false); if (oldSession != null) { name = (String)
		 * oldSession.getAttribute("user"); session_email = (String)
		 * oldSession.getAttribute("email"); oldSession.invalidate(); } // generate a
		 * new session HttpSession session = request.getSession(true);
		 * 
		 * // setting session to expiry in 10 mins session.setMaxInactiveInterval(10 *
		 * 60); if (name == null) { name = "Live"; } session.setAttribute("user", name);
		 */
		// Try: Take the input parameters to pertain search parameters.
		HttpSession session = request.getSession();

		People search_user = new People();
		search_user.setUsername(request.getParameter("user").toString().trim());
		search_user.setFirst_name(request.getParameter("first_name").toString().trim());
		search_user.setLast_name(request.getParameter("last_name").toString().trim());
		search_user.setEmail(request.getParameter("email").toString().trim());

			
		String username = request.getParameter("user").toString().trim();
		String email = request.getParameter("email").toString().trim();
		String first_name = request.getParameter("first_name").toString().trim();
		String last_name = request.getParameter("last_name").toString().trim();
		// System.out.println("Into Search Controller" + "Params "+ username + " " +
		// email);

		// Dao--> our data acess object. Will fetch data from db
		PeopleDao dao = new PeopleDao();
		people = dao.getPeople(username, email, first_name, last_name);

		// Create model based on Dao object.
		// People p = dao.getPerson(username, email);
		/**
		 * if(first_name.isEmpty() && last_name.isEmpty()) { people =
		 * dao.getPeople(username, email); } else { people = dao.getPeople(username,
		 * email, first_name,last_name); }
		 **/

		// Chect what's coming in from Dao model.
		
		// Session is used to store what was being searched to restore the state later.
		session.setAttribute("search_query", search_user);
		request.setAttribute("people", people);
		// System.out.println("the people object sent outta search people " + people);
		RequestDispatcher rd = request.getRequestDispatcher("showPeople.jsp");
		rd.forward(request, response);

	}

}
