/**
 * 
 */
package controllers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * @author sanat.parmar
 * The class to establish and remove connection with the database.
 */
public class ConnectDb {
	private Connection connection = null;

	/**
	 * 
	 * @param link
	 * @param login
	 * @param pass
	 * @return connection object. Null in case if connection is not established.
	 */
	public Connection getConnection(String link, String login, String pass) {
	
			try {
				Class.forName("com.mysql.jdbc.Driver");
				connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/person_management", "root", "");
				System.out.println("ConnectionDB: Connection established");

			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
		return connection;
	}

	public void setConn(Connection conn) {
		this.connection = conn;
	}


}
