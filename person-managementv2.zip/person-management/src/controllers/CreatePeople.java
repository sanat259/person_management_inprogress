package controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.createUsers;

/**
 * Create Person. Adds new record into people database and redirects to
 * createPeople page.
 */
public class CreatePeople extends HttpServlet {

	// To remove warning.
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, IllegalArgumentException {
		/**
		 * Get the request @param Recieve Arguments from Request and update them into
		 * the database.
		 */
		
		String username = request.getParameter("username").toString();
		String email = request.getParameter("email").toString();
		String first_name = request.getParameter("first_name").toString();
		String last_name = request.getParameter("last_name").toString();
		String role = request.getParameter("role").toString();
		String password = request.getParameter("password").toString();
		System.out.println(
				"Into Create Controller" + "Params " + username + " " + email + " " + first_name + " " + last_name);
		
		PeopleDao dao = new PeopleDao();
		createUsers create = dao.createPeople(username, email, first_name, last_name, role, password);
		boolean result = create.getStatus()==1? true: false;
		System.out.println(" Create Controller - Created user: " + result);
		HttpSession session = request.getSession();
		/*
		 * if (result) { request.setAttribute("isSuccess", result); }
		 */
		session.setAttribute("create", create);
		System.out.println("The create controller output: "+ create);
		RequestDispatcher rd = request.getRequestDispatcher("createPeople.jsp");
		rd.forward(request, response);

	}

}
