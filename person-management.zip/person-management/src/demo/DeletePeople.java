package demo;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DeletePeople
 */
public class DeletePeople extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("Delete Servlet triggered");
		/**
		 * @param Get the request parameters
		 */
		String email = request.getParameter("email").toString();
		System.out.println("Into Delete Controller" + "Params " + email);

		// Dao--> our data acess object. Will Delete given row
		PeopleDao dao = new PeopleDao();
		boolean result = dao.deletePeople(email);

		/** To display users after delete **/
		System.out.println(" Delete Controller - Deleted user: " + result);
		String username = "";
		String email1 = "";
		String first_name = "";
		String last_name = "";
		ArrayList<People> people = dao.getPeople(username, email1, first_name, last_name);

		request.setAttribute("people", people);
		RequestDispatcher rd = request.getRequestDispatcher("showPeople.jsp");
		rd.forward(request, response);
	}

}
