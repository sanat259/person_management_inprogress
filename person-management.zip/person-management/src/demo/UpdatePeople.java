package demo;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UpdatePeople
 */
public class UpdatePeople extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		/**
		 * Get the request @param
		 * 
		 */
		String username = request.getParameter("username").toString();
		String email = request.getParameter("email").toString();
		String first_name = request.getParameter("first_name").toString();
		String last_name = request.getParameter("last_name").toString();
		String role = request.getParameter("role").toString();
		// String password = request.getParameter("password").toString();
		System.out.println(
				"Into Update Controller" + "Params " + username + " " + email + " " + first_name + " " + last_name);

		// Dao--> our data access object. Will create new person
		PeopleDao dao = new PeopleDao();
		boolean result = dao.updatePeople(username, email, first_name, last_name, role);
		System.out.println("  Controller - Update user: " + result);
		if (result) {
			request.setAttribute("isSuccess", result);
		}

		/** To display users after delete **/
		System.out.println(" Delete Controller - Deleted user: " + result);
		String username1 = "";
		String email2 = "";
		String first_name1 = "";
		String last_name1 = "";
		ArrayList<People> people = dao.getPeople(username1, email2, first_name1, last_name1);

		request.setAttribute("people", people);
		RequestDispatcher rd = request.getRequestDispatcher("showPeople.jsp");
		rd.forward(request, response);

	}

}
