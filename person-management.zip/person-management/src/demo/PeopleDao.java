package demo;



import com.mysql.jdbc.Statement;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Connection;
import java.util.ArrayList;

public class PeopleDao {
	private Connection conn = null;

	public ArrayList<People> getPeople(String username, String email, String first_name, String last_name) {
		ArrayList<People> people = new ArrayList<People>();
		People p;
		java.sql.PreparedStatement ps;
		// System.out.println("People Dao input parameter : " +email);

		try {

			try {
				// Load the driver
				Class.forName("com.mysql.jdbc.Driver");
				conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/person_management", "root", "");
				System.out.println("People DAO : Database Connected");
				if (username.isEmpty() && email.isEmpty() && first_name.isEmpty() && last_name.isEmpty()) {
					ps = conn.prepareStatement("select * from people");

				}

				else {
					ps = conn.prepareStatement(
							"SELECT * from people WHERE email LIKE ? and username LIKE ? and first_name LIKE ? and last_name LIKE ?");
					ps.setString(1, email+ "%");
					ps.setString(2, username+ "%");
					ps.setString(3, first_name+ "%");
					ps.setString(4, last_name+ "%");
				}
				System.out.println(ps);
				ResultSet rs = ps.executeQuery();
				System.out.println(
						"the query outputgetPeople(String username, String email, String first_name, String last_name): "
								+ rs.getFetchSize());
				while (rs.next()) {
					p = new People();
					p.setEmail(rs.getString("email"));
					p.setUsername(rs.getString("username"));
					p.setFirst_name(rs.getString("first_name"));
					p.setLast_name(rs.getString("last_name"));
					p.setRole(rs.getString("role"));
					System.out.println(p);
					people.add(p);
					System.out.println("Added: " + p + " To Arraylist : " + people);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

			// gets a new connection

		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Output: getpeople():" + people);
		return people;

	}

	public boolean createPeople(String username, String email, String first_name, String last_name, String role,
			String password) {
		boolean isSuccess = false;
		java.sql.PreparedStatement ps;

		try {
			// Load the driver
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/person_management", "root", "");
			System.out.println("People DAO Create : Database Connected");
			
			Statement st = (Statement) conn.createStatement();
			// if you only need a few columns, specify them by name instead of using "*"
			String query = "SELECT MD5('" + password + "') as encrypted";
			System.out.println(" Query for encryption::" + query);
			String encrypted_pass = null;
			// execute the query, and get a java resultset
			ResultSet rs = st.executeQuery(query);
			while (rs.next()) {
				encrypted_pass = rs.getString("encrypted");
				// Log encrypted Pass Result
				System.out.println(" The Encrypted password:" + encrypted_pass);

			}

			ps = conn.prepareStatement(
					"insert into people(first_name, last_name, email, username, password, role) values (?,?,?,?,?,?)");
			System.out.println(ps);
			ps.setString(1, first_name);
			ps.setString(2, last_name);
			ps.setString(3, email);
			ps.setString(4, username);
			ps.setString(5, encrypted_pass);
			ps.setString(6, role);
			System.out.println(ps);

			int result = ps.executeUpdate();
			if (result == 0) {
				isSuccess = false;
			} else {
				isSuccess = true;
			}
		}

		catch (Exception e) {
			isSuccess = false;
		}

		System.out.println("Result of create :" + isSuccess);
		return isSuccess;
	}

	public boolean deletePeople(String email) {
		boolean isSuccess = false;
		java.sql.PreparedStatement ps;

		try {
			// Load the driver
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/person_management", "root", "");
			System.out.println("People DAO Delete : Database Connected");
			ps = conn.prepareStatement("delete from people where email=?");

			ps.setString(1, email);

			int result = ps.executeUpdate();
			if (result == 0) {
				isSuccess = false;
			} else {
				isSuccess = true;
			}
		}

		catch (Exception e) {
			isSuccess = false;
		}

		System.out.println("Result of delete :" + isSuccess);
		return isSuccess;
	}

	public boolean updatePeople(String username, String email, String first_name, String last_name, String role) {
		boolean isSuccess = false;
		java.sql.PreparedStatement ps;

		try {
			// Load the driver
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/person_management", "root", "");
			System.out.println("People DAO Update : Database Connected");
			ps = conn.prepareStatement(
					"update people set first_name=?, last_name=?, email=?, username=?, role=? where email=?");

			ps.setString(1, first_name);
			ps.setString(2, last_name);
			ps.setString(3, email);
			ps.setString(4, username);
			// ps.setString(5, password);
			ps.setString(5, role);
			ps.setString(6, email);
			int result = ps.executeUpdate();
			if (result == 0) {
				isSuccess = false;
			} else {
				isSuccess = true;
			}
		}

		catch (Exception e) {
			isSuccess = false;
		}

		System.out.println("Result of Update :" + isSuccess);
		return isSuccess;
	}

	// check whether user is already active
	/*
	 * public boolean isActive(String email) throws ClassNotFoundException,
	 * SQLException { Class.forName("com.mysql.jdbc.Driver"); conn =
	 * DriverManager.getConnection("jdbc:mysql://localhost:3306/person_management",
	 * "root", ""); System.out.println("People DAO Update : Database Connected");
	 * java.sql.Statement st = conn.createStatement(); java.sql.PreparedStatement ps
	 * = conn.prepareStatement("select * from active where email=?");
	 * ps.setString(1, email); System.out.println(ps); ResultSet rs =
	 * ps.executeQuery();
	 * 
	 * while (rs.next()) { return true; }
	 * 
	 * return false; }
	 */

	// Adds user to active list.
	/*
	 * public boolean activate(String email) throws SQLException,
	 * ClassNotFoundException { try { Class.forName("com.mysql.jdbc.Driver"); conn =
	 * DriverManager.getConnection("jdbc:mysql://localhost:3306/person_management",
	 * "root", ""); System.out.println("People DAO Activate : Database Connected");
	 * java.sql.Statement st = conn.createStatement();
	 * 
	 * java.sql.PreparedStatement ps2 =
	 * conn.prepareStatement("insert into active(email) values (?)");
	 * ps2.setString(1, email); int result = ps2.executeUpdate(); if (result == 0) {
	 * return false; } else {
	 * System.out.println("USer Successfully added to active list."); return true; }
	 * } catch (Exception e) { // TODO: handle exception return false; } }
	 */

	// Removes user from active list
	/*
	 * public boolean deactivate(String email) throws SQLException,
	 * ClassNotFoundException { boolean isSuccess; try {
	 * Class.forName("com.mysql.jdbc.Driver"); conn =
	 * DriverManager.getConnection("jdbc:mysql://localhost:3306/person_management",
	 * "root", "");
	 * System.out.println("People DAO Deactivate : Database Connected");
	 * 
	 * java.sql.PreparedStatement ps2 =
	 * conn.prepareStatement("delete from active where email=?"); ps2.setString(1,
	 * email); int result = ps2.executeUpdate(); if (result == 0) { isSuccess =
	 * false; } else { isSuccess = true; } }
	 * 
	 * catch (Exception e) { isSuccess = false; }
	 * 
	 * System.out.println("Result of deactivation from active users :" + isSuccess);
	 * return isSuccess; }
	 */

}
