package demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * Servlet implementation class Login
 */
public class Login extends HttpServlet {

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, NullPointerException {

		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();

		// Connect to mySql and verify username an password.
		try {
			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/person_management", "root",
						""); // gets a new connection
				// System.out.print("Database is connected !");

				// Get paramaters from request.
				String uname = request.getParameter("uname").toString();
				String pass = request.getParameter("pass").toString();

				// Check if user is already active.
				PeopleDao dao = new PeopleDao();
				//boolean isActive = dao.isActive(uname);

				//if (!isActive) {
					// Encrypt Password
					Statement st = (Statement) conn.createStatement();
					String query = "SELECT MD5('" + pass + "') as encrypted";
					System.out.println(" Query for encryption::" + query);
					String encrypted_pass = null;
					
					// execute the query, and get a java resultset
					ResultSet rs1 = st.executeQuery(query);
					while (rs1.next()) {
						encrypted_pass = rs1.getString("encrypted");
						System.out.println(" The Encrypted password:" + encrypted_pass);

						// print the results
					}
					java.sql.PreparedStatement ps = conn
							.prepareStatement("select username,first_name,last_name, email,password from people where username=? and password=?");
					ps.setString(1, uname);
					ps.setString(2, encrypted_pass);
					ResultSet rs = ps.executeQuery();
					while (rs.next()) {
						// Put user into active list.
						//dao.activate(uname);
						HttpSession session;
						// Get the old session and invalidate
						HttpSession oldSession = request.getSession(false);
						if (oldSession != null) {
							//Restore old session if present
							session = oldSession;
							System.out.println("Restoring old session");
						}
						else {
							// generate a new session
							 session = request.getSession(true);
							 System.out.println("Creating new session");
						}
						
						

						// setting session to expiry in 10 mins
						session.setMaxInactiveInterval(10 * 60);

						String name = rs.getString(1);
						String email = rs.getString(2);
						session.setAttribute("user", name);
						session.setAttribute("email", email);
						RequestDispatcher rd = request.getRequestDispatcher("home.jsp");
						// System.out.println(session.getAttribute("user"));
						rd.forward(request, response);
						// System.out.println(session);
						return;
					//}
				}

				/*if (isActive) {
					out.println(
							"<font color='orange'><b>User is already logged in. Please log out from other systems and try again.</b></font>");
					RequestDispatcher rd = request.getRequestDispatcher("login.html");
					rd.include(request, response);
					conn.close();
					return;
				  }*/

				
				out.println("<font color='red'><b>You have entered incorrect password</b></font>");
				RequestDispatcher rd = request.getRequestDispatcher("login.html");
				rd.include(request, response);
				conn.close();
				return;

			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				System.out.println("JDBC Connection" + e);
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} finally {
			out.close();
		}

	}

}
