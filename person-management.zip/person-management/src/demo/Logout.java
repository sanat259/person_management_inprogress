package demo;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Logout
 */
public class Logout extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		session.removeAttribute("user");
		session.removeAttribute("email");
		session.invalidate();

		// Remove from active list of users.
		//PeopleDao dao = new PeopleDao();
		/*
		 * try { boolean isdeactivated = dao.deactivate(email);
		 * System.out.println("Deactivated : " + email); } catch (ClassNotFoundException
		 * e) { // TODO Auto-generated catch block
		 * System.out.println("Error removing email from active list.");
		 * e.printStackTrace(); } catch (SQLException e) { // TODO Auto-generated catch
		 * block e.printStackTrace(); }
		 */
		System.out.println("Session cleared: Logging out");
		RequestDispatcher rd = request.getRequestDispatcher("login.html");
		rd.include(request, response);
	}

}
