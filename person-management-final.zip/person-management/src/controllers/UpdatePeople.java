package controllers;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.People;

/**
 * Servlet implementation class UpdatePeople
 */
public class UpdatePeople extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	People search_query;
	HttpSession session;
	People search_user;
	
	String search_query_username;
	String search_query_email;
	String search_query_first_name;
	String search_query_last_name;
	
	String username;
    String email;
    String first_name;
    String last_name; 
    String role;
	ArrayList<People> people;


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, NullPointerException {
		/**
		 * Get the request @param
		 * 
		 */
		
		// Get the original search parameter to update the list later.
		this.search_query = (People) request.getSession(false).getAttribute("search_query");
		this.session = request.getSession(true);
		
		//Prevents NullPointerException
		if(request== null || session== null) {
			RequestDispatcher rd = request.getRequestDispatcher("showPeople.jsp");
			rd.forward(request, response);
			return;
		}

		try {
		this.search_user= new People();
		search_user.setUsername(request.getParameter("user").toString().trim());
		search_user.setFirst_name(request.getParameter("first_name").toString().trim());
		search_user.setLast_name(request.getParameter("last_name").toString().trim());
		search_user.setEmail(request.getParameter("email").toString().trim());
		System.out.println("The update: Search query:"+ search_user);
		}
		catch (Exception e) {
			// TODO: handle exception
			
		}
		//Set up parameters to persorm update.
		username = request.getParameter("update_username").toString();
	    email = request.getParameter("update_email").toString();
	    first_name = request.getParameter("update_first_name").toString();
		last_name = request.getParameter("update_last_name").toString();
		role = request.getParameter("update_role").toString();
		// String password = request.getParameter("password").toString();
		System.out.println(
				"Into Update Controller" + "Params " + username + " " + email + " " + first_name + " " + last_name);

		// Dao--> our data access object. Will create new person
		PeopleDao dao = new PeopleDao();
		boolean result = dao.updatePeople(username, email, first_name, last_name, role);
		System.out.println("  Controller - Update user: " + result);
		if (result) {
			session.setAttribute("updateResult", result);
		}
		

		/** To display users after update **/
		try {
			if(search_query!=null) {
			search_query_username = (search_query.getUsername() == null || search_query.getUsername() == "") ? ""
					: search_query.getUsername();
			search_query_email = search_query.getEmail() == null ? "" : search_query.getEmail();
			search_query_first_name = search_query.getFirst_name() == null ? "" : search_query.getFirst_name();
			search_query_last_name = search_query.getLast_name() == null ? "" : search_query.getLast_name();
			people = dao.getPeople(search_query_username, search_query_email, search_query_first_name,
					search_query_last_name);
			request.setAttribute("people", people);
			}

			RequestDispatcher rd = request.getRequestDispatcher("showPeople.jsp");
			rd.forward(request, response);
			return;
		} catch (Exception e) {
			people = dao.getPeople("", "", "", "");
			request.setAttribute("people", people);
			RequestDispatcher rd = request.getRequestDispatcher("showPeople.jsp");
			rd.forward(request, response);
		}
	}

}
