package controllers;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.People;

/**
 * Servlet implementation class DeletePeople
 */
public class DeletePeople extends HttpServlet {
	private static final long serialVersionUID = 1L;
	People search_query;
	HttpSession session;
	String username;
	PeopleDao dao;
	boolean isPresent;
	boolean delete_result;
	String search_query_username;
	String search_query_email;
	String search_query_first_name;
	String search_query_last_name;
	ArrayList<People> people;

	/**
	 * Get the input parameters
	 * @param request
	 * @param response
	 */
	protected void getParams(HttpServletRequest request, HttpServletResponse response) {
		// Get the original search parameter to update the list later. Http session
		// updates the query result to display page.
		this.search_query = (People) request.getSession(false).getAttribute("search_query");
		this.session = request.getSession(true);

		// Get the user name(key) of record to be deleted.
		this.username = request.getParameter("delete_username").toString();
		System.out.println("Into Delete Controller" + "Params " + username);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, NullPointerException {
		System.out.println("Delete Servlet triggered");
		/**
		 * @param Get the request parameters
		 */
		getParams(request, response);
		
		//Prevents NullPointerException
		if(request== null || session== null) {
			RequestDispatcher rd = request.getRequestDispatcher("showPeople.jsp");
			rd.forward(request, response);
			return;
		}

		// Dao--> our data acess object. Will Delete given row
		dao = new PeopleDao();

		isPresent = dao.fetchRecord(username);
		System.out.println("Fetching Query before deleting:" + isPresent);

		if (!isPresent) {
			System.out.println("Unable to Delete. Record is not available in the database.");
			delete_result = false;
		} else {
			delete_result = dao.deletePeople(username);
			System.out.println(" Delete Controller - Deleted user: " + delete_result);
		}

		// Set the result of delete in session.
		session.setAttribute("deleteResult", delete_result);

		/** To display users after delete **/
		try {
			if(search_query!= null) {
			search_query_username = (search_query.getUsername() == null || search_query.getUsername() == "") ? ""
					: search_query.getUsername();
			search_query_email = search_query.getEmail() == null ? "" : search_query.getEmail();
			search_query_first_name = search_query.getFirst_name() == null ? "" : search_query.getFirst_name();
			search_query_last_name = search_query.getLast_name() == null ? "" : search_query.getLast_name();
			people = dao.getPeople(search_query_username, search_query_email, search_query_first_name,
					search_query_last_name);
			request.setAttribute("people", people);
			}
			RequestDispatcher rd = request.getRequestDispatcher("showPeople.jsp");
			rd.forward(request, response);
			return;
		} catch (Exception e) {
			people = dao.getPeople("", "", "", "");
			request.setAttribute("people", people);
			RequestDispatcher rd = request.getRequestDispatcher("showPeople.jsp");
			rd.forward(request, response);
		}
	}

}
