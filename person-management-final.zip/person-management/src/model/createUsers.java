/**
 * 
 */
package model;
/**
 * @author sanat.parmar
 * @param int status = 0 (init)
 * @param int status = 1 (success)
   @param int status = 2 (failure)
 */
public class createUsers {
	int status; 
	String username;
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public createUsers() {
		// TODO Auto-generated constructor stub
		status=0;
		username=null;
	}
	
	
}
