package controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.People;
/**
 * Servlet implementation class Login
 */
public class Login extends HttpServlet {

	private static final long serialVersionUID = 2708995553814559002L;
	People user;
	String uname;
	String pass;
	PeopleDao dao;
	HttpSession session;
	HttpSession oldSession;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, NullPointerException {
		
		// The login credentials of user
		this.user = new People();
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		// Get paramaters from request.
		this.uname = request.getParameter("uname").toString();
		this.pass = request.getParameter("pass").toString();

		// Connect to mySql and verify username an password.
		try {
			    this.dao = new PeopleDao();

				user = dao.login(uname, pass);
				// Get user login data and pass it in the home.jsp
				if(user!= null) {
				System.out.println(" Login servelet user: " + user);
				
				
						// Get the old session and invalidate
					oldSession = request.getSession(false);
					if (oldSession != null) {
					  //Restore old session if present
					  session = oldSession;
					  System.out.println("Restoring old session");
					}
					else {
						// generate a new session
						session = request.getSession(true);
						System.out.println("Creating new session");
						}
						session.setAttribute("user", user.getFirst_name() + " " + user.getLast_name());
						session.setAttribute("email", user.getEmail());
						session.setAttribute("loginDetails", user);
						
						// setting session to expiry in 10 mins
						session.setMaxInactiveInterval(10 * 60);
						user.setUsername(user.getUsername());
						
						RequestDispatcher rd = request.getRequestDispatcher("home.jsp");
						// System.out.println(session.getAttribute("user"));
						rd.forward(request, response);
						// System.out.println(session);
						return;
				}
			
				out.println("<font color='red'><b>You have entered incorrect username or password</b></font>");
				RequestDispatcher rd = request.getRequestDispatcher("login.html");
				rd.include(request, response);
				return;
		
			} catch (Exception e) {
				e.printStackTrace();
			}
		 finally {
			out.close();
		}

	}

}
