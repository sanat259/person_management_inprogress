package controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.createUsers;

/**
 * Create Person. Adds new record into people database and redirects to
 * createPeople page.
 */
public class CreatePeople extends HttpServlet {

	// To remove warning.
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	String username;
	String email;
	String first_name;
	String last_name;
	String role;
	String password;
	HttpSession session;
	createUsers create;
	boolean create_result;

	/**
	 * Fetch values from the request object.
	 * 
	 * @param request
	 * @param response
	 */
	protected void getRequestParams(HttpServletRequest request, HttpServletResponse response) {
		this.username = request.getParameter("username").toString();
		this.email = request.getParameter("email").toString();
		this.first_name = request.getParameter("first_name").toString();
		this.last_name = request.getParameter("last_name").toString();
		this.role = request.getParameter("role").toString();
		this.password = request.getParameter("password").toString();
		System.out.println("Request parameters fetched.");
	}

	/**
	 * Executes queries to create a user an returns the result as create result
	 * object {Status_code, Username}
	 * 
	 * @return createUSer object
	 */
	protected createUsers createUser() {
		createUsers createUser = new createUsers();
		PeopleDao dao = new PeopleDao();
		createUser = dao.createPeople(this.username, this.email, this.first_name, this.last_name, this.role,
				this.password);
		System.out.println("Create User Method: Query Executed.");
		return createUser;
	}

	/**
	 * Sets the session attributes.
	 * 
	 * @param request
	 * @param response
	 */
	protected void setSessionAttributes(HttpServletRequest request, HttpServletResponse response) {
		this.session = request.getSession();
		session.setAttribute("create", create);
		System.out.println("The create controller output: " + create);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, IllegalArgumentException {
		/**
		 * Get the request @param Recieve Arguments from Request and update them into
		 * the database.
		 */
		getRequestParams(request, response);
		System.out.println(
				"Into Create Controller" + "Params " + username + " " + email + " " + first_name + " " + last_name);

		this.create = createUser();
		this.create_result = create.getStatus() == 1 ? true : false;
		System.out.println(" Create Controller - Created user: " + create_result);
		setSessionAttributes(request, response);

		// Return the results and redirect to create people page.
		RequestDispatcher rd = request.getRequestDispatcher("createPeople.jsp");
		rd.forward(request, response);

	}

}
