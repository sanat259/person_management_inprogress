package controllers;

import com.mysql.jdbc.Statement;

import model.People;
import model.createUsers;
import controllers.ConnectDb;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;
import java.util.ArrayList;

public class PeopleDao {
	/**
	 * DB connection configuration.
	 */
	private Connection conn = null;
	ConnectDb db = new ConnectDb();
	final String db_link = "jdbc:mysql://localhost:3306/person_management";
	final String db_username = "root";
	final String db_pass = "";

	/**
	 * 
	 * @param username
	 * @param email
	 * @param first_name
	 * @param last_name
	 * @return ArrayList<People>
	 * 
	 *  Fetches a list of people from the database from the search query.
	 */
	public ArrayList<People> getPeople(String username, String email, String first_name, String last_name) {
		ArrayList<People> people = new ArrayList<People>();
		People p;
		java.sql.PreparedStatement ps;
		// System.out.println("People Dao input parameter : " +email);

		try {

			try {
				conn = db.getConnection(db_link, db_username, db_pass);
				// conn =
				// DriverManager.getConnection("jdbc:mysql://localhost:3306/person_management",
				// "root", "");
				// System.out.println("People DAO : Database Connected");
				if ((username.isEmpty() || username.equals("")) && (email.isEmpty() || email.equals(""))
						&& (first_name.isEmpty() || first_name.equals(""))
						&& (last_name.isEmpty() || last_name.equals(""))) {
					ps = conn.prepareStatement("select * from people order by updated_on DESC");
				} else {
					ps = conn.prepareStatement(
							"SELECT * from people WHERE email LIKE ? and username LIKE ? and first_name LIKE ? and last_name LIKE ? order by updated_on DESC");
					ps.setString(1, email + "%");
					ps.setString(2, username + "%");
					ps.setString(3, first_name + "%");
					ps.setString(4, last_name + "%");
				}
				System.out.println(ps);
				ResultSet rs = ps.executeQuery();

				while (rs.next()) {
					p = new People();
					p.setEmail(rs.getString("email"));
					p.setUsername(rs.getString("username"));
					p.setFirst_name(rs.getString("first_name"));
					p.setLast_name(rs.getString("last_name"));
					p.setRole(rs.getString("role"));
					people.add(p);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		db.closeConnection(); // Close the connection
		return people;

	}

	/**
	 * 
	 * @param username
	 * @param email
	 * @param first_name
	 * @param last_name
	 * @param role
	 * @param password
	 * @return Person
	 * 
	 *         Encrypts the password. Creates a new user, returns Person object of
	 *         the created record if successful.
	 */
	public createUsers createPeople(String username, String email, String first_name, String last_name, String role,
			String password) {
		createUsers create = new createUsers();
		// boolean isSuccess = false;
		java.sql.PreparedStatement ps;

		try {
			// Load the driver
			/*
			 * Class.forName("com.mysql.jdbc.Driver"); conn =
			 * DriverManager.getConnection("jdbc:mysql://localhost:3306/person_management",
			 * "root", "");
			 */
			conn = db.getConnection(db_link, db_username, db_pass);

			Statement st = (Statement) conn.createStatement();
			// Encrypt the password.
			String query = "SELECT MD5('" + password + "') as encrypted";
			System.out.println(" Query for encryption::" + query);
			String encrypted_pass = null;
			// Get the Encrypted Password.
			ResultSet rs = st.executeQuery(query);
			while (rs.next()) {
				encrypted_pass = rs.getString("encrypted");
			}

			ps = conn.prepareStatement(
					"insert into people(first_name, last_name, email, username, password, role) values (?,?,?,?,?,?)");
			System.out.println(ps);
			ps.setString(1, first_name);
			ps.setString(2, last_name);
			ps.setString(3, email);
			ps.setString(4, username);
			ps.setString(5, encrypted_pass);
			ps.setString(6, role);
			System.out.println(ps);
			int result = ps.executeUpdate();
			if (result == 0) {
				// isSuccess = false;
				create.setStatus(2);
				create.setUsername(username);

			} else {
				// isSuccess = true;
				create.setStatus(1);
				create.setUsername(username);
			}
		}

		catch (Exception e) {
			// isSuccess = false;
			create.setStatus(2);
			create.setUsername(username);
		}
		db.closeConnection();
		return create;
	}

	/**
	 * 
	 * @param username
	 * @return Boolean success/ failure
	 * 
	 *         Deletes a record from the database.
	 */
	public boolean deletePeople(String username) {
		boolean isSuccess = false;
		java.sql.PreparedStatement ps;

		try {
			/*
			 * // Load the driver Class.forName("com.mysql.jdbc.Driver"); conn =
			 * DriverManager.getConnection("jdbc:mysql://localhost:3306/person_management",
			 * "root", "");
			 */
			conn = db.getConnection(db_link, db_username, db_pass);
			ps = conn.prepareStatement("delete from people where username=?");
			ps.setString(1, username);
			int result = ps.executeUpdate();
			if (result == 0) {
				isSuccess = false;
			} else {
				isSuccess = true;
			}
		} catch (Exception e) {
			isSuccess = false;
		}

		System.out.println("Result of delete :" + isSuccess);
		db.closeConnection();
		return isSuccess;
	}

	/**
	 * 
	 * @param username
	 * @param email
	 * @param first_name
	 * @param last_name
	 * @param role
	 * @return boolean
	 * 
	 *         Queries and updates the record, based on the input params.
	 */
	public boolean updatePeople(String username, String email, String first_name, String last_name, String role) {
		boolean isSuccess = false;
		java.sql.PreparedStatement ps;

		try {

			conn = db.getConnection(db_link, db_username, db_pass);
			System.out.println("People DAO Update : Database Connected");
			ps = conn.prepareStatement(
					"update people set first_name=?, last_name=?, email=?, username=?, role=? where username=?");

			ps.setString(1, first_name);
			ps.setString(2, last_name);
			ps.setString(3, email);
			ps.setString(4, username);
			// ps.setString(5, password);
			ps.setString(5, role);
			ps.setString(6, username);
			System.out.println("Update query: " + ps);
			int result = ps.executeUpdate();
			if (result == 0) {
				isSuccess = false;
			} else {
				isSuccess = true;
			}
		}

		catch (Exception e) {
			isSuccess = false;
		}

		System.out.println("Result of Update :" + isSuccess);
		db.closeConnection();
		return isSuccess;
	}

	/**
	 * Checks if the record is present in the DB.
	 * 
	 * @param username
	 * @return boolean result: true if record is present, false if record is not
	 *         present.
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public boolean fetchRecord(String username) {

		try {
			conn = db.getConnection(db_link, db_username, db_pass);
			java.sql.PreparedStatement ps = conn.prepareStatement("select * from people where username=?");
			ps.setString(1, username);
			System.out.println(ps);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				return true;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		db.closeConnection();
		return false;
	}

	public People login(String username, String password) {
		People user = new People();
		String encrypted_pass = null;
		try {
			conn = db.getConnection(db_link, db_username, db_pass);
			Statement st = (Statement) conn.createStatement();
			String query = "SELECT MD5('" + password + "') as encrypted";
			System.out.println(" Query for encryption::" + query);

			// Get the password encrypted.
			ResultSet rs1 = st.executeQuery(query);
			while (rs1.next()) {
				encrypted_pass = rs1.getString("encrypted");
				System.out.println(" The Encrypted password:" + encrypted_pass);
			}
			java.sql.PreparedStatement ps = conn.prepareStatement(
					"select username,first_name,last_name, email,password, role from people where username=? and password=?");
			ps.setString(1, username);
			ps.setString(2, encrypted_pass);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				user.setUsername(rs.getString(1));
				user.setFirst_name(rs.getString(2));
				user.setLast_name(rs.getString(3));
				user.setEmail(rs.getString(4));
				user.setRole(rs.getString(6));
				System.out.println("DAO: Login Success. Fetched user : " + user);
				db.closeConnection();
				return user;
			}
			return null;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			return null;
		}
	}
}

// check whether user is already active
/*
 * public boolean isActive(String email) throws ClassNotFoundException,
 * SQLException { Class.forName("com.mysql.jdbc.Driver"); conn =
 * DriverManager.getConnection("jdbc:mysql://localhost:3306/person_management",
 * "root", ""); System.out.println("People DAO Update : Database Connected");
 * java.sql.Statement st = conn.createStatement(); java.sql.PreparedStatement ps
 * = conn.prepareStatement("select * from active where email=?");
 * ps.setString(1, email); System.out.println(ps); ResultSet rs =
 * ps.executeQuery();
 * 
 * while (rs.next()) { return true; }
 * 
 * return false; }
 */

// Adds user to active list.
/*
 * public boolean activate(String email) throws SQLException,
 * ClassNotFoundException { try { Class.forName("com.mysql.jdbc.Driver"); conn =
 * DriverManager.getConnection("jdbc:mysql://localhost:3306/person_management",
 * "root", ""); System.out.println("People DAO Activate : Database Connected");
 * java.sql.Statement st = conn.createStatement();
 * 
 * java.sql.PreparedStatement ps2 =
 * conn.prepareStatement("insert into active(email) values (?)");
 * ps2.setString(1, email); int result = ps2.executeUpdate(); if (result == 0) {
 * return false; } else {
 * System.out.println("USer Successfully added to active list."); return true; }
 * } catch (Exception e) { // TODO: handle exception return false; } }
 */

// Removes user from active list
/*
 * public boolean deactivate(String email) throws SQLException,
 * ClassNotFoundException { boolean isSuccess; try {
 * Class.forName("com.mysql.jdbc.Driver"); conn =
 * DriverManager.getConnection("jdbc:mysql://localhost:3306/person_management",
 * "root", "");
 * System.out.println("People DAO Deactivate : Database Connected");
 * 
 * java.sql.PreparedStatement ps2 =
 * conn.prepareStatement("delete from active where email=?"); ps2.setString(1,
 * email); int result = ps2.executeUpdate(); if (result == 0) { isSuccess =
 * false; } else { isSuccess = true; } }
 * 
 * catch (Exception e) { isSuccess = false; }
 * 
 * System.out.println("Result of deactivation from active users :" + isSuccess);
 * return isSuccess; }
 */
